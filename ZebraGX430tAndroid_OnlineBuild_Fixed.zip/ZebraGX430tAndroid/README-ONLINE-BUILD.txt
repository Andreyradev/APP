Zebra GX430t Controller — online Android APK build

This project uses Kotlin + Jetpack Compose and Gradle. It is not a Kivy/Buildozer project.
The Android module is configured to compile both Java and Kotlin bytecode to JVM 17.

For online build through GitHub Actions:
1. Upload this ZIP file into the repository root.
2. The workflow should extract ZebraGX430tAndroid_OnlineBuild*.zip into the repository root.
3. Run Gradle from the extracted ZebraGX430tAndroid folder.
4. On success, download ZebraGX430tController-debug-apk from the workflow Artifacts.

The resulting APK is a debug build for testing. It has not been independently device-tested.
The phone and printer must be on the same local network, and the printer must be reachable on TCP port 9100.
